package field;

import plants.Plant;

public class Field {
    public Plant[][] spaces;

    public Field() {
        spaces = new Plant[10][10];
    }

    /**
     * This method should plant a provided plant in the given
     * field space. If the field space is not empty, it should
     * throw a FieldNotTilledException.
     * @param plant The provided Plant object
     * @param row The provided row
     * @param column The provided column
     * @throws FieldNotTilledException
     */

    /**
     * writeToFile
     * This method should write the current field out to a file
     * called 'field.txt'. It should match the format produced by
     * toString. See the specification for more information.
     */

    /**
     * toString
     * This method should produce a string representation of the current field.
     * See the specification for more information and formatting requirements.
     * @return A text representation of the field
     */
}
