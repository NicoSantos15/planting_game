package game;

import plants.*;

import java.util.ArrayList;

public class Player {
    private int funds;
    public ArrayList<Plant> seedlings = new ArrayList<>();

    public Player() {
        funds = 200;
    }

    /**
     * getPlant
     * This method searches the player's seedlings list for a
     * plant object that matches the type provided. The method must determine
     * the subclass of each Plant object in the list and return
     * the first that matches the provided type. It should also remove
     * it from the seedlings list. If there are no matching seedling
     * objects of the provided type, it should throw a
     * NoAvailableSeedlingException. See the specification for more information.
     * @param type A string representation of the Plant type
     * @return The first matching plant object from the seedlings list
     * @throws NoAvailableSeedlingException
     */

    /**
     * pay
     * This method attempts to subtract a provided amount from the player's
     * funds. If there is not enough money, it should throw an
     * InsufficientFundsException. See the specification for more information.
     * @param payment The amount to be deducted
     * @throws InsufficientFundsException
     */

    /**
     * Increments funds by the provided amount.
     * @param income
     */
    public void addIncome(int income) {
        funds += income;
    }

    public int getFunds() {
        return funds;
    }
}
